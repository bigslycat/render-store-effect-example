/* @flow */

import * as React from 'react';

import { Root } from '../Root';

export const Label = (props: {}) => <Root as='label' {...props} />;

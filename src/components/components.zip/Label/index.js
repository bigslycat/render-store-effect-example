/* @flow */

export * from './Label';

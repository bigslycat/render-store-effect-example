/* @flow */

import * as React from 'react';

import { Root } from '../Root';

export const A = (props: {}) => <Root as='a' {...props} />;

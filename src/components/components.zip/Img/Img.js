/* @flow */

import * as React from 'react';

import { Root } from '../Root';

export const Img = (props: {}) => <Root as='img' {...props} />;
